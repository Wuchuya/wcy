<?php
header("content-type:text/html; charset=utf-8");
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
include 'D:/web/PHPExcel-1.8/Classes/PHPExcel.php';
include 'D:/web/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';
include_once 'D:/web/PHPExcel-1.8/Classes/PHPExcel/Writer/Excel5.php';
include_once 'D:/web/PHPExcel-1.8/Classes/PHPExcel/Reader/Excel5.php';

$PHPExcel = new PHPExcel();
$filename = "D:/web/index.xls";

$PHPReader = new \PHPExcel_Reader_Excel5();
// 载入文件
$objPHPExcel = $PHPReader->load($filename);
// 获取表中的第一个工作表，如果要获取第二个，把0改为1，依次类推
$objPHPExcel->setActiveSheetIndex(0);//设置第一个Sheet


$arr=array();
$wzsz=array();
//从哪行开始有几行
for ($i=32;$i<278;$i++){
    $data = $objPHPExcel->getActiveSheet()->getCell('E'.($i+1))->getValue()-$objPHPExcel->getActiveSheet()->getCell('E'.$i)->getValue();

    if ($data!=1){
      $str=$objPHPExcel->getActiveSheet()->getCell('E'.$i)->getValue();

       $wz=$objPHPExcel->getActiveSheet()->getCell('G'.$i)->getValue();
       /*echo"<br/>";*/
        //截取字符长度
        $zfc=substr($str,15,5);
        /*echo "<br/>";*/
        for ($j=1;$j<$data;$j++){
            //排序生成缺少的字符串
           $write=substr($str,0,15).$zfc+$j.'G';//
//            echo "<br>";
            array_push($wzsz,$wz);
           array_push($arr,$write);
        }
    }
}
print_r($arr);
echo "<br/>";
print_r($wzsz);

foreach ($arr as $key=>$value){

    $objPHPExcel->getActiveSheet()->setCellValue('T'.($key+2), $value);
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('D:/web/index.xls');
}
foreach ($wzsz as $key=>$value){
    $objPHPExcel->getActiveSheet()->setCellValue('U'.($key+2), $value);
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('D:/web/index.xls');
}
















/*for ($j=2;$j<287;$j++){
    $data2 = $objPHPExcel->getActiveSheet()->getCell('E'.($j+1))->getValue();
    echo $data2;
    echo "<br/>";
}*/
/*for ($j=3;$j<285;$j++){
    $data = $objPHPExcel->getActiveSheet()->getCell('E'.$j)->getValue();
    echo $data;
    echo"<br/>";
}*/


//$currentSheet = $PHPExcel->getSheet(0);
// 获取总列数


